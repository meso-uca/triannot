<h1 align=center><?php echo $title ?></h1>
<hr>
<br>
    <?php
    if($mode == 1){
    ?>
    <form method="post" action="./?page=connection&req=login"><br>
        <input oninput="changeUrl(this)" placeholder="<?php echo $texts['login_placeholder']; ?>" type="text" class="form-control" name="login"/><br>
        <input placeholder="<?php echo $texts['password_placeholder']; ?>" type="password" class="form-control" name=password />
        <a id="forget" href="./?page=connection&req=forget"><?php echo $texts['forget_password']; ?></a><br><br>
        <input type="submit" class="btn btn-primary" name="loginSubmit" value="<?php echo $texts['button_form_default']; ?>" />     
    </form>
    <script>
        function changeUrl(el)
        {
            var url = './?page=connection&req=forget&login=';
            $('#forget').attr("href", url + $(el).val())
        }
    </script>
    <?php
    }else if ($mode == 2){
    ?>
    <form method="post" action="./?page=connection&req=register"><br>
        <input placeholder="<?php echo $texts['login_placeholder']; ?>" type="text" class="form-control" name="login"/><br>
        <input placeholder="<?php echo $texts['password_placeholder']; ?>" type="password" class="form-control" name=password /><br>
        <input placeholder="<?php echo $texts['password_repeat_placeholder']; ?>" type="password" class="form-control" name=password2 /><br>
        <input placeholder="<?php echo $texts['email_placeholder']; ?>" type="text" class="form-control" name="email" /><br>
        <input type="submit" class="btn btn-primary" name="registerSubmit" value="<?php echo $texts['button_form_default']; ?>"/>     
    </form>
    <?php
    } else if ($mode == 3)
    {
    ?>
        <h4><?php echo $texts['change_your_password']; ?></h4>
        <form method="post" action="./?page=connection&req=forget&login=<?php echo $SQLGP_nospeci['login']; ?>&token=<?php echo $SQLGP_nospeci['token']; ?>"><br>
            <input placeholder="<?php echo $texts['password_placeholder']; ?>" type="password" class="form-control" name=password /><br>
            <input placeholder="<?php echo $texts['password_repeat_placeholder']; ?>" type="password" class="form-control" name=password2 /><br>
            <input type="submit" class="btn btn-primary" name="changePasswordSubmit" value="<?php echo $texts['button_form_default']; ?>"/>     
        </form>
    <?php
    }
    ?>
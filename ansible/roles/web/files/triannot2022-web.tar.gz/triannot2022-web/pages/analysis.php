
<h1 align=center><?php echo $texts['my_analysis']; ?></h1>
<hr>
<br>
<?php 
if($shareLink != false)
{
?>
<div class="row">
    <a onclick="copyLink(this)" class="btn btn-primary"><?php echo $texts['copy_link']; ?></a>
    <input id="link" style="width:50%" type="text" class="col-5 form-control" value="<?php echo $shareLink; ?>"/>
</div>
<?php } ?>
<br><br>
<table id="datatable" class="table">
    <thead>
        <tr>
            <th><?php echo $texts['column_0']; ?></th>
            <th class="sortable-column"><?php echo $texts['column_1']; ?></th>
            <th><?php echo $texts['column_2']; ?></th>
            <th class="sortable-column"><?php echo $texts['column_3']; ?></th>
            <th class="sortable-column"><?php echo $texts['column_4']; ?></th>
            <th><?php echo $texts['column_5']; ?></th>
            <th><?= $texts['column_6'];?></th>
        </tr>
    </thead>
    <tbody>
        
        <?php
        //mettre dans l'ordre inverse des id (pour l'affichage)
        $arr = array_reverse($arr);
        foreach ($arr as $key => $value) {
            //get infos dir
            if(!isHidden($link,$value[0])){

                $dir = getDir($value[0], $link);
                $infos = getInfoOfRequest($value[0],$link);

                ?>
                <tr>
                    <td>
                        
                        <div id=<?php 
                            echo "\"showDetailHide".$value[2]."\"";
                            // if state == finished
                            if($value[3] == 0 || $value[3] == 1) echo "style=\"display : none;\""
                        ?>>
                        <a style="cursor:pointer;display: flex;align-items: center;" onclick="showNext(this)">
                        Download 
                        <i style="margin-left:3px;" class="fas fa-chevron-down"></i>
                        </a>
                        <div style="display: none;">
                            <A href="<?php echo "./?page=analysis&req=".$SQLGP_nospeci['req'] . '&download=1&type=2&id='.$value[0];?>"><i class="fas fa-file-download"></i> tar.gz</A><br>
                            <!-- <A href="" target="_blank"><i class="fas fa-tv"></i> JBrowse</A><br> -->
                            <?php if(isAdmin($link)) { ?><A href="<?php echo "./?page=analysis&req=".$SQLGP_nospeci['req'] . '&download=1&type=6&id='.$value[0];?>" download="log.txt">Log</A><br><?php } ?>
                        </div>
                        </div>
                    </td>
                    <td><A href="<?php echo "./?page=analysis&req=".$SQLGP_nospeci['req'] . '&download=1&type=1&id='.$value[0];?>"><?php echo $value[1]; ?></A></td>
                    <td>
                        <a style="cursor:pointer;display: flex;align-items: center;" onclick="showNext(this)">Show details <i style="margin-left:3px;"  class="fas fa-chevron-down"></i></a>
                        <div style="display: none;">
                            <span>Min sequence length : <?php echo $infos->req_min_size ?></span><br>
                            <span>Max sequence length : <?php echo $infos->req_max_size ?></span><br>
                            <span>Sequence type : <?php echo $infos->tmo_libelle ?></span><br>
                            <span>Split seq : <?php echo $infos->req_splitseq==0 ? "<i class='fa fa-circle-xmark' style='color:red'></i>":"<i class='fa fa-circle-check' style='color:green'></i>" ?></span><br>
                            <span>Overlap : <?php echo $infos->req_overlap ?></span><br>
                            <span>XML step : <?php echo $infos->ana_libelle ?></span><br>
                            <span>Code : <?php echo '<a target="_blank" href="./?page=analysis&req=one&id='. $value[2].'">'.$value[2].'</a>'; ?></span><br>
                        </div>
                    </td>
                    <!-- Date -->
                    <?php 
                    echo "<td>". $value[5]."</td>";
                    ?>
                    <!-- State -->
                    <?php
                        if($value[3] == 0 || $value[3] == 2 || $value[3] == 3)
                            $req=mysqli_query($link,"select sta_libelle,sta_couleur from tr_statut_sta where sta_id='$value[3]'");
                        else $req=mysqli_query($link,"select sta_libelle,sta_couleur from tr_statut_sta where sta_id=1");
                        $nb=mysqli_num_rows($req);
                        $res=mysqli_fetch_object($req);
                        ?>
                        <td id="tdstate<?php echo $value[2]; ?>" BGCOLOR="<?php echo $res->sta_couleur; ?>">
                        <?php 
                        if($value[3] == 0 || $value[3] == 1 || $value[3] == 2 || $value[3] == 3)
                            echo $res->sta_libelle; 
							// When the % of running is added : uncomment below and remove "|| $value[3] == 1"
                        // else echo $value[3];
                        ?>
                        </td>
                        <?php
                    ?>
                    <td>
                        <input class='custom-slider' type='range' disabled min=0 max=100 value="<?=$infos->req_progress?>"><?=$infos->req_progress?>%
                    </td>
                    <td align='center'><?php if($value[3] != 3){ ?><a href="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>&delete=<?php echo $value[0] ?>"><i class="fas fa-times"></i></a><?php } ?>
                    </td>
                </tr>
        <?php
            }
        }
        ?>
        
    </tbody>
</table>
<script>
    <?php if($isFormSubmited){
        ?>
            window.location.href = '<?php echo './?page=analysis&req=one&id='. $value[2]; ?>';
    <?php
    }
    ?>
    <?php if($SQLGP_nospeci['req'] == 'one' || $SQLGP_nospeci['req'] == 'own'){
        ?>
    
    function reloadState(str) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                const results = this.responseText.split('/');
                $('#tdstate' + str).attr("bgcolor",results[0]);
                $('#tdstate' + str).text(results[1]);
                if($('#tdstate' + str).text() === "finished") $("#showDetailHide" + str).attr('style', '')
                else $("#showDetailHide" + str).attr('style', 'display:none;')
            }
        };
        xmlhttp.open("GET", "ajaxRequest/analysisInfo.php?id=" + str, true);
        xmlhttp.send();
    }

    var intervalId = window.setInterval(function(){
        <?php
        $arr = array_reverse($arr);
        foreach ($arr as $key => $value) {

            ?>
        reloadState('<?php echo $value[2]; ?>');
        <?php
        }
        ?>
    }, 10000);

    
    <?php
    }
    ?>
    
</script>
<script>
    $(document).ready( function () {
        $('#datatable').DataTable();
    });

    function showNext(el){
        if($(el).next().is(":visible")){
            $(el).children().removeClass('fa-chevron-up')
            $(el).children().addClass('fa-chevron-down')
            $(el).next().hide()
        }else{
            $(el).children().removeClass('fa-chevron-down')
            $(el).children().addClass('fa-chevron-up')
            $(el).next().show()
        }
    }

    function copyLink(el){
        var copyText = document.getElementById("link");

        copyText.select();
        copyText.setSelectionRange(0, 99999);

        navigator.clipboard.writeText(copyText.value);

        $(el).text('<?php echo $texts['copy_link_copied']; ?>');
    }
</script>

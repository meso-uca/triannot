<?php

//Check if submit form :

//check if logout:
//check if session log out
if($page_validation && $page == "logout"){
  session_destroy();
  $page = "form";
}

$oldmask = umask(000);

if(isset($SQLGP_nospeci['submitForm']))
{
    //Verification du formulaire :
    if(isset($SQLGP_nospeci['min_size']) && !empty($SQLGP_nospeci['min_size']) 
    && isset($SQLGP_nospeci['max_size']) && !empty($SQLGP_nospeci['max_size'])
    && isset($_FILES['sequences']['name']) && !empty($_FILES['sequences']['name']))
    {
        //Verification de la conformité des informations :

        if($SQLGP_nospeci['min_size'] >= 0)
        {
            if($SQLGP_nospeci['max_size'] >= 0)
            {
                $date=getdate();
                $dir='Upload/';
                $str_date=$date["year"].'/';@mkdir ($dir.$str_date,0777);
                $str_date=$str_date.$date["mon"].'/';@mkdir ($dir.$str_date,0777);
                $str_date=$str_date.$date["mday"].'/';@mkdir ($dir.$str_date,0777);
                $str_date.=$_SESSION['loginUser']."/";@mkdir ($dir.$str_date,0777);
                $dir=$dir.$str_date;
                $dir=$dir;
                $dir2="Upload/".$str_date;
                $code=RandomString(25);
                while (isCodeExist($code,$link)){
                    $code=RandomString(25);
                }
                
                $dir.=$code."/";@mkdir ($dir, 0777);
                $target_dir = $dir;

                $extension = pathinfo($_FILES["sequences"]["name"])["extension"];
                //check file name
                $new_name = cleanString(pathinfo($_FILES["sequences"]["name"])['filename']);
                $_FILES["sequences"]["name"] = $new_name;
                $_FILES["sequences"]["name"] .= "." . $extension;
                $target_file = $target_dir . basename($_FILES["sequences"]["name"]);
                $uploadOk = 0;
                if(!empty($_FILES["sequences"]['name']))
                    $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                
                //Check si le fichier est une sequence (fasta file)
                if ($uploadOk == 0) {
                    $error = $messages['file_empty'];
                    } else {
                    if($_FILES['sequences']['size'] > 20971520) {
                        $error = $messages['file_size_error'];
                    } else {
                        
                        
                        
                        if (move_uploaded_file($_FILES["sequences"]["tmp_name"], $target_file)) {
                            $sql2='INSERT INTO t_request_req (req_sequences,req_code, req_statut, req_login,req_date, req_tmo_id,req_min_size,req_max_size,req_splitseq,req_overlap,req_ana_id) VALUES ("'.$_FILES["sequences"]["name"].'","' .$code .'",0,"'.$_SESSION['loginUser'].'","'.$date["year"]."-".$date["mon"]."-".$date["mday"].'","'.$SQLGP_nospeci['type_sequence'].'","'.$SQLGP_nospeci['min_size'].'","'.$SQLGP_nospeci['max_size'].'","'.($SQLGP_nospeci['splitseq'] == "on" ? 1 : 0).'","'.$SQLGP_nospeci['overlap'].'","'.$SQLGP_nospeci['xml_step'].'")';
			    file_put_contents('php://stderr', print_r($sql2, TRUE));
                            // echo $sql2;exit;
                            $req2 = mysqli_query($link,$sql2);  
                            $success = "The file ". htmlspecialchars( basename( $_FILES["sequences"]["name"])). " has been uploaded.";
                            $page = 'analysis';
                            $id = mysqli_insert_id($link);
                            //if(mysqli_query($link,'SELECT req_code FROM t_request_req WHERE req_id = "'.$id.'"') != false)
                            //die(header("Location: ./?page=analysis&req=one&success=1&id=".mysqli_query($link,'SELECT req_code FROM t_request_req WHERE req_id = "'.$id.'"')->fetch_object()->req_code));
                            //exit;
                            $page = "analysis";
                            $isFormSubmited = true;
                            $SQLGP_nospeci['req'] = "one";
                            $SQLGP_nospeci['success'] = 1;
                            $SQLGP_nospeci['id'] = mysqli_query($link,'SELECT req_code FROM t_request_req WHERE req_id = "'.$id.'"')->fetch_object()->req_code;
                        } else {
                            $error = $messages['error_path_or_upload'];
                        }
                    }
                }
            }else $error = $messages['error_max_size'];
        }else $error = $messages['error_min_size'];
    }else $error = $messages['form_empty'];
}

//delete (move to tr_delete_del)
if(isset($SQLGP_nospeci['delete']) && !empty($SQLGP_nospeci['delete']))
{
    $req = mysqli_query($link, 'SELECT req_id, req_statut, req_code, req_date FROM t_request_req WHERE req_id = ' .$SQLGP_nospeci['delete']);
    $nb=mysqli_num_rows($req);
    if ( $nb != 0 ){
        $arr=mysqli_fetch_all($req);
        
        //on check si il n'est pas déjà dans la table delete :
        $req = mysqli_query($link, 'SELECT del_id FROM tr_delete_del WHERE del_id = ' .$SQLGP_nospeci['delete']);
        $nb=mysqli_num_rows($req);
        if ( $nb == 0 ){
            //Si le statut est 'en cours' ou 'en attente'
            if($arr[0][1] == 0 || $arr[0][1] == 1 || $arr[0][1] == 2)
            {
                mysqli_query($link,'INSERT INTO tr_delete_del (del_id, del_code,del_date,del_login) VALUES ('.$arr[0][0].', "'.$arr[0][2].'", "'.$arr[0][3].'", "'.$_SESSION["loginUser"].'")');
                mysqli_query($link,'DELETE FROM t_request_req WHERE req_id = '.$SQLGP_nospeci['delete']);

                //On redirige vers new analysis si visiteur, sinon vers my analysis
                if($_SESSION['id'] == -1) $redirect = './?page=form';
                else {
                    $redirect = './?page=analysis&req=own';
                }
                header('Location: ' .$redirect);
            }
        }
    }
}

if(isset($SQLGP_nospeci['download']) && isset($SQLGP_nospeci['type']) && isset($SQLGP_nospeci['id']))
{
    $dir = mysqli_query($link,'SELECT req_date FROM t_request_req WHERE req_id = "'.$SQLGP_nospeci['id'].'"')->fetch_object()->req_date;
    $file = mysqli_query($link,'SELECT req_code FROM t_request_req WHERE req_id = "'.$SQLGP_nospeci['id'].'"')->fetch_object()->req_code;
    $dir = preg_replace('/-/', '/', $dir);
    $dir.='/';
    $dir .= getDir($SQLGP_nospeci['id'], $link);
    $filename = pathinfo(mysqli_query($link,'SELECT req_sequences FROM t_request_req WHERE req_id = "'.$SQLGP_nospeci['id'] .'"')->fetch_object()->req_sequences)['filename'];

    switch($SQLGP_nospeci['type']){
        //Le fichier de base
        case '1':
            $dir = 'Upload/'.$dir;
            $dir.=mysqli_query($link,'SELECT req_sequences FROM t_request_req WHERE req_id = "'.$SQLGP_nospeci['id'] .'"')->fetch_object()->req_sequences;
            $filename = mysqli_query($link,'SELECT req_sequences FROM t_request_req WHERE req_id = "'.$SQLGP_nospeci['id'] .'"')->fetch_object()->req_sequences;
            break;
        //cas resultat
        case '2':
            $filename .= '.tar.tar.gz';
            $dir = 'Upload/'.$dir;
            $dir.=$file.'.tar.gz';
            break;
        //cas genbank
        case '3':
            $filename .= '.gb.tar.gz';
            $dir = 'Upload/'.$dir;
            $dir.='Res_gb_annot.tar.gz';
            break;
        //cas gff
        case 4:
            $filename .= '.gff.tar.gz';
            $dir = 'Upload/'.$dir;
            $dir.='Res_gff_annot.tar.gz';
            break;
        //cas warning
        case 5:
            $filename .= '.warning.tar.gz';
            $dir = 'Upload/'.$dir;
            $dir.='Res_warnings.tar.gz';
			break;
        // log.txt
        case 6:
            $filename .= '.txt';
            $dir = 'Upload/'.$dir;
            $dir.="log.txt";
            break;
        // ??
        case 7:
            break;
    }
    if (file_exists($dir)) {
        
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($dir));
        
        readfile($dir);
        exit;
    }
    
}



//Login
if(isset($SQLGP_nospeci['loginSubmit'])){
    if(!empty($SQLGP_nospeci['password']) && !empty($SQLGP_nospeci['login'])){
        //Check le user et le mdp dans la bdd : 
        $res = checkPassword($SQLGP_nospeci['login'],$SQLGP_nospeci['password'],$link);
        //Utilisateur ok et mdp ok
        if($res != -1){
          $_SESSION["id"]=$res;
          $_SESSION["loginUser"]=$SQLGP_nospeci['login'];
          $page = "form";
          //die(header("Location: ./?page=form"));
          //exit;
        }else{
            $error = $messages['incorrect_login_or_password'];
        }
    }else{
        $error = $messages['form_empty'];
    }
}

if(isset($SQLGP_nospeci['registerSubmit'])){
    if(!empty($SQLGP_nospeci['password']) && !empty($SQLGP_nospeci['login']) && !empty($SQLGP_nospeci['password2'])){
        //Check le user et déjà dans la bdd ou non : 
        if(checkUserExist($SQLGP_nospeci['login'],$link)){
            if(hashPassword($SQLGP_nospeci['password']) == hashPassword($SQLGP_nospeci['password2'])){
                if(isset($SQLGP_nospeci['email']) && !empty($SQLGP_nospeci['email']))
                    $req=mysqli_query($link,'INSERT INTO t_users_use (use_login,use_mdp,use_level,use_mail) VALUES ("'.$SQLGP_nospeci['login'].'","'.hashPassword($SQLGP_nospeci['password']).'",0,"'.$SQLGP_nospeci['email'].'")');
                else
                    $req=mysqli_query($link,'INSERT INTO t_users_use (use_login,use_mdp,use_level) VALUES ("'.$SQLGP_nospeci['login'].'","'.hashPassword($SQLGP_nospeci['password']).'",0)');
                if($req)
                    $success = $messages['success_register'];
                else $messages['unknown_error'];
            }else $error = $messages['passwords_not_same'];
        } else $error = $messages['login_already_in_database'];
        
    }else{
        $error = $messages['form_empty'];
    }
}

umask($oldmask);

?>

<!-- start: header -->
<header class="header" style="display:flex;justify-content: space-between;">
    <div class="logo-container" >
        <h2 style="margin-left:15px;margin-top:8px"><a style="text-decoration:none;" href="./?page=form">
                <?php echo $texts['title']; ?>
            </a></h2>
        
        <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>

    <!-- start: search & user box -->
    <div class="header-right">
        <ul class="notifications">
            <form class="form-inline">
                <div style="display:flex">
                    <div class="form-group mb-2">
                        <input type="text" class="form-control" name="searchCode" placeholder="<?php echo $texts['search_bar_placeholder']; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2"><?php echo $texts['search_bar_button']; ?></button>
                </div>
            </form>
        </ul>

        <span class="separator"></span>

        <div id="userbox" class="userbox">
            <?php
            if ($_SESSION["loginUser"] == "visitor") {
            ?>
                <a data-toggle="dropdown">
                    <div class="profile-info">
                        <a href="./?page=connection&req=login" class="btn" style="color:grey"><?php echo $texts['Login_Button'] ?></a>
                        <a href="./?page=connection&req=register" class="btn" style="color:grey"><?php echo $texts['Register_Button'] ?></a>
                    </div>
                </a>
            <?php
            } else {
            ?>
                <a href="#" data-toggle="dropdown">
                    <div class="profile-info">
                        <span class="name"><?php echo $_SESSION["loginUser"]; ?></span>
                    </div>
                    <i class="fa custom-caret"></i>
                </a>
            <?php
            }
            ?>
            <div class="dropdown-menu">
                <ul class="list-unstyled">
                    <li>
                        <a role="menuitem" href="./?page=logout"><i class="fas fa-sign-out-alt"></i> <?php echo $texts['logout_button'] ?></a>
                    </li>
                </ul>
            </div>
        </div>
        <span class="separator"></span>
    </div>
</header>
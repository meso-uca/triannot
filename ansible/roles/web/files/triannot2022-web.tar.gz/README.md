# MicroAnnot New website version

> Informations sur le site du projet MicroAnnot (Maj 15/12/2021). Chef de projet : Jeremy Tournayre

Tout ce passe dans 'index.php', qui va ensuite include les pages en fonction des paramètres (GET et POST) et des variables de sessions.

Trois pages principales : 
1. Connexion : Inscription / Connexion / Retrouver le mot de passe perdu
2. Formulaire d'upload de fichier
3. Visualisation des analyses : en fonction d'un utilisateur (liste d'analyses) ou d'une seule analyse

## La page de formulaire

1. 5 champs 'number', dont deux avec une limite minimum d'insertion en php (backend).
2. 1 champ de sélection 
3. 2 selectbox (dont un visible seulement en étant admin)
4. 1 upload de fichier (limite à 20mo en back)

## La page de visualisation d'analyse(s)

Un lien est accessible dans la sidebar (à gauche) lorsqu'on est connecté. Il ramène directement à la liste des analyses effectuées par l'utilisateur.

Dans cette liste chaque ligne possède des caractéristiques sous forme de tableau :
1. Download : télécharger les résultats de l'analyse (Upload_2)
2. Sequence : le nom du fichier qui a été upload : un clique dessus le télécharge (Upload)
3. Informations : Les caractéristiques qui ont été saisie dans le formulaire
4. Analysis begin : La date d'upload du formulaire
5. Statut : l'état de l'analyse :
   1. Pending
   2. Finished
   3. Fail
   4. <s>Running</s> Running + % ??
6. Une croix pour pouvoir supprimer l'analyse (déplacement dans une table destiné à la suppression) -> suppression possible seulement pour les états 'pending' et 'running'

## La page de connexion

Se connecter, s'inscrire et retrouver son mot de passe.
Pour retrouver son mot de passe il faut avoir saisi son mail lors de l'inscription.

## La page d'info (help)

Connaitre les informations sur le projet

## Header

Un header commun à toutes les pages avec :
  1. Un formulaire avec un champ text et un bouton pour permettre la recherche via un code d'analyse (redirection vers la page de visualisation d'analyse)
  2. Des boutons Log in et Register (remplacés par le login de la session si l'utilisateur est connecté)

# Personnalisation 

## Traduction

Tout les texts et écritures sont dans config/vars.php sous forme de tableau :

```php
//Example
$texts = [
    //main
    'title' => 'MicroAnnot',

    //header
    'Application_Name' => 'MicroAnnot',
    'Login_Button' => 'Log in',
    'Register_Button' => 'Register',
    'logout_button' => 'Log out'
]
```

## Base de données

La base de donnée a été réalisé avec les normes de syntaxe : t_users_use ...
Elle se trouve dans bdd/microannot.sql

La configuration pour la connexion dans config/da_ba_co.php

```php
define("HOST","");
define("USER","");
define("MDP","");
define("DBNAME","microannot");
```

## Session

Possibilité de changer la durée max de la session dans config/sess.php

```php
ini_set('session.gc_maxlifetime', 10800);
```

# Dossier d'upload

Apache à besoin des droits pour écrire dans le fichier d'upload ("Upload" par défaut). Commandes utiles pour la création d'un dossier avec les permissions (recursif) :

```
setfacl -Rdm "u:microannot:rwx" **dossier**
setfacl -Rdm "g:www-data:rx" **dossier**
setfacl -Rdm "u:www-data:rwx" **dossier**
```

<?php
if(isset($_GET['id']) && $_GET['id'] != null){
    //requete sql pour obtenir les infos de l'analyse avec l'id
    include('../config/da_ba_co.php');
    $link=mysqli_connect(HOST,USER,MDP,DBNAME) or die("Could not connect to the database");
    $requete = 'SELECT req_statut FROM t_request_req WHERE req_code = "'.$_GET['id'].'"';
    $el = mysqli_query($link,$requete);
    $state = $el->fetch_object()->req_statut;
    if($state == 0 || $state == 2 || $state == 3)
        $req=mysqli_query($link,"select sta_libelle,sta_couleur from tr_statut_sta where sta_id='$state'");
    else
        $req=mysqli_query($link,"select sta_libelle,sta_couleur from tr_statut_sta where sta_id=1");
    $nb=mysqli_num_rows($req);
    $res=mysqli_fetch_object($req);
    echo $res->sta_couleur . "/";
    if($state == 0 || $state == 1 || $state == 2 || $state == 3)
        echo $res->sta_libelle;
		// When the % of running is added : uncomment below and remove "|| $value[3] == 1"
    // else 
        // echo $state;
    
}else{
    echo 'Id could not be empty';
}
?>
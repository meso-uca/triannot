<?php

    if(isset($_POST['password']) && isset($_POST['password2']))
    {
      $passwordNoEncrypted = $_POST['password'];
      $passwordNoEncrypted2 = $_POST['password2'];
    }

    $unwanted_array = array('Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
                                                  'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
                                                  'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
                                                  'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
                                                  'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y' );

    foreach ($_GET as $key=>$val){
      if (is_array($_GET[$key])){
        foreach ($_GET[$key] as $key2=>$val2){
                  $SQL[$key][$key2]=mysqli_real_escape_string($link,$val2);
                  $GP_nospeci[$key][$key2]= strtr( $_GET[$key], $unwanted_array );
                  $GP_nospeci_rn[$key][$key2]=preg_replace('/[^A-Za-z0-9\r\n_\->\.@]/', '', $GP_nospeci[$key][$key2]);
                  $SQLGP_nospeci[$key][$key2]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key][$key2]);
                  $SQLGP_nospeci[$key][$key2]=mysqli_real_escape_string($link,$SQLGP_nospeci[$key][$key2]);
                  $GP_nospeci[$key][$key2]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key][$key2]);
        }
      }
      else{
                  $SQL[$key]=mysqli_real_escape_string($link,$_GET[$key]);
                  $GP_nospeci[$key]= strtr( $_GET[$key], $unwanted_array );
                  $GP_nospeci_rn[$key]=preg_replace('/[^A-Za-z0-9\r\n_\->\.@]/', '', $GP_nospeci[$key]);
                  $SQLGP_nospeci[$key]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key]);
                  $SQLGP_nospeci[$key]=mysqli_real_escape_string($link,$SQLGP_nospeci[$key]);
                  $GP_nospeci[$key]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key]);
      }
    }

    foreach ($_POST as $key=>$val){
      if (is_array($_POST[$key])){
        foreach ($_POST[$key] as $key2=>$val2){
                  $SQL[$key][$key2]=mysqli_real_escape_string($link,$val2);
                  $GP_nospeci[$key][$key2]= strtr( $_POST[$key][$key2], $unwanted_array );
                  $GP_nospeci_rn[$key][$key2]=preg_replace('/[^A-Za-z0-9\r\n_\->\.@]/', '', $GP_nospeci[$key][$key2]);
                  $SQLGP_nospeci[$key][$key2]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key][$key2]);
                  $SQLGP_nospeci[$key][$key2]=mysqli_real_escape_string($link,$SQLGP_nospeci[$key][$key2]);
                  $GP_nospeci[$key][$key2]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key][$key2]);
        }
      }
      else{
                  $SQL[$key]=mysqli_real_escape_string($link,$_POST[$key]);
                  $GP_nospeci[$key]= strtr( $_POST[$key], $unwanted_array );
                  $GP_nospeci_rn[$key]=preg_replace('/[^A-Za-z0-9\r\n_\->\.@]/', '', $GP_nospeci[$key]);
                  $SQLGP_nospeci[$key]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key]);
                  $SQLGP_nospeci[$key]=mysqli_real_escape_string($link,$SQLGP_nospeci[$key]);
                  $GP_nospeci[$key]=preg_replace('/[^A-Za-z0-9_\->\.@]/', '', $GP_nospeci[$key]);
      }
    }

    if(isset($_POST['password']) && isset($_POST['password2']))
    {
      $SQLGP_nospeci['password'] = $passwordNoEncrypted;
      $SQLGP_nospeci['password2'] = $passwordNoEncrypted2;
    }
    
    $isFormSubmited = false;
    $page_validation = false;

    $list_pages = array (
      "form" =>  1,
      "connection" =>  1,
      "logout" =>  1,
      "help" =>  1,
      "softwares" =>  1,
      "databanks" =>  1,
      "aknowledgments" =>1,
      "analysis" =>  1);
      
    $page="";
    if (isset($SQLGP_nospeci['page'])){
      $page=$SQLGP_nospeci['page'];
      unset($SQLGP_nospeci['page']);
    } else $page = 'form';

    if (isset($page) && isset($list_pages[$page]) && $list_pages[$page]==1){
      $page_validation = true;
    }

    if(isset($SQLGP_nospeci['searchCode']) && !empty($SQLGP_nospeci['searchCode'])){
      $page = "analysis";
      $SQLGP_nospeci['req'] = "one";
      $SQLGP_nospeci['id'] = $SQLGP_nospeci['searchCode'];
      $redirect = "./?page=analysis&req=one&id=".$SQLGP_nospeci['searchCode'];
      //die(header("Location: ./?page=analysis&req=one&id=".$SQLGP_nospeci['searchCode']));
      //exit;
    }

    $error = false;
    $success = false;
    $errorFormulaire = false;
    $warning = false;
    include 'config/functions.php';
    
    include 'config/formProcessing.php';

    if (!isset($_SESSION["id"])){
      $_SESSION["id"]=-1;
      $_SESSION["loginUser"]="visitor";
  }
?>
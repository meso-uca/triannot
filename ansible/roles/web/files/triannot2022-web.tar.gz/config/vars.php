<?php

$texts = [

    //main
    'title' => 'TriAnnot',

    //header
    'Application_Name' => 'TriAnnot',
    'Login_Button' => 'Log in',
    'Register_Button' => 'Register',
    'logout_button' => 'Log out',
    //sidebar
    'new_analysis' => 'New analysis',
    'my_analysis' => 'My analysis',
    'help' => 'Help',
    //Help
    'help_title' => 'Help TriAnnot',
    'help_top_page' => 'Help TriAnnot',
    //form
    'form_title' => 'Form of TriAnnot',
    //file input
    'file_span' => 'Input sequence(s) (fasta file)',
    'file_change' => 'Change file',
    'file_select' => 'Select file',
    'file_delete' => 'Delete file',
    //info 1
    'min_length' => 'Sequence length',
    'min_size' => 'Minimal sequence length',
    'max_size' => 'Maximal sequence length',
    'parameters' => 'Parameters',
    'cds_prediction_span' => 'Minimum size for CDS prediction (min: 300)',
    'sequence_type' => 'Sequence type',
    'splitseq' => 'Splitseq',
    'overlap' => 'Overlap',
    'xml_steps' => 'XML step',

    //my analysis page
    'my_analysis_title' => 'Request list',
    'copy_link' => 'Copy link',
    'copy_link_copied' => 'Copied !',
    'column_0' => '',
    'column_1' => 'Sequences',
    'column_2' => 'Informations',
    'column_3' => 'Analysis begin',
    'column_4' => 'Statut',
    'column_5' => 'Progress',
    'column_6' => '',

    //button submit for all pages
    'button_form_default' => 'Submit',
    'button_reset_default' => 'Reset',

    //login && register page
    'connection_title' => 'Connection',
    'login_title' => 'Log in',
    'login_placeholder' => 'Login',
    'password_placeholder' => 'Password',
    'email_placeholder' => 'Email (optionnal, in case you forget your password)',
    'password_repeat_placeholder' => 'Repeat Password',
    'register_title' => 'Register',
    'forget_password' => 'I lost my password',
    'forget_password_title' => 'Forget Password',
    'request_password_changer' => 'We sent you a mail to change your password (login : ',
    'request_password_changer_user_not_in_database' => 'Login isn\'t in the dabatase (login : ',
    'request_password_changer_no_email' => 'No email with this login (login : ',
    'change_your_password' => 'Create a new password',
    'login_missing' => 'Enter first a login before click on "I lost my password"',

    //searchBar
    'search_bar_placeholder' => 'CODE',
    'search_bar_button' => 'Search ..',

];

$messages = [
    //warning
    'no_analysis_found' => 'No analysis found',

    //error
    '404' => '<b>404</b> - page not found',
    'unknown_error' => 'Error',

    //error form
    'file_empty' => 'The form needs a file',
    'file_size_error' => 'File size > 20 MB',
    'error_path_or_upload' => "Sorry, there was an error uploading your file.",
    'orf_error_min' => 'Minimum size of ORF finding is 200',
    'error_min_size' => 'Min size should be higher than 0',
    'error_max_size' => 'Max size should be higher than 0',
    
    //Empty fields (all website forms)
    'form_empty' => 'Some fields are empty',

    //error login or register
    'incorrect_login_or_password' => 'Wrong Login or Password',
    'login_already_in_database' => 'Login already in database',
    'passwords_not_same' => 'Passwords are not the same',
    'wrong_token' => 'Wrong token',
    'link_expired' => 'Link expired',

    //Success messages
    'success_register' => 'Completed ! You can log in now (<a href=\'./?page=connection&req=login\'>Log in</a>)',
    'success_file_upload' => 'The file has been uploaded.',
    'success_password_change' => 'Password changed (<a href="./?page=connection&req=login">Log in</a>)',

    //Email
    'title_mail' => 'Change Password MicroAnnot',
    'message_mail' => 'Click on this link to change your password : '


];
<?php 

// function mysqli_fetch_all($result) {
//     $select = array();

//     while( $row = mysqli_fetch_array($result) ) {
//         $select[] = $row;
//     }

//     return $select;
// }

function hashPassword($pass)
{
    $psw="981ai".$pass."64sd6s4v";
    $psw=md5($psw);
    $psw=md5($psw);

    return $psw;
}

function checkPassword($user, $password,$link)
{
    $response = -1;
    
    $psw = hashPassword($password);

    $sql = 'SELECT * FROM t_users_use WHERE use_login = "'. $user . '" and use_mdp = "' . $psw .'"';
    $req=mysqli_query($link,$sql);
    $nb=mysqli_num_rows($req);
    if ( $nb != 0 ){
        $arr=mysqli_fetch_all($req);
        $response = $arr[0][0];
    } 

    return $response;
}



function checkUserExist($user,$link)
{
    $response = false;

    $sql = 'SELECT * FROM t_users_use WHERE use_login = "'. $user . '"';
    $req=mysqli_query($link,$sql);
    $nb=mysqli_num_rows($req);
    if ( $nb == 0 ) $response = true;

    return $response;
}

function RandomString($longueur = 10) { 
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($longueur/strlen($x)) )),1,$longueur);
}

function dd($el)
{
    var_dump($el);
    die();
}

function getDir($id,$link)
{
    //$dir = '';
    
    $code = mysqli_query($link, 'SELECT req_code FROM t_request_req WHERE req_id ="'.$id.'"')->fetch_object()->req_code;
    $login = mysqli_query($link, 'SELECT req_login FROM t_request_req WHERE req_id ="'.$id.'"')->fetch_object()->req_login;
    /*$dir.=preg_split('/-/', $res)[0] . '/';
    $dir.=preg_split('/-/', $res)[1] . '/';
    $dir.=preg_split('/_/', preg_split('/-/', $res)[2])[0] . '/';
    $dir.=$login.'/';
    preg_match('/>(.*)/', $res, $last);
    //> 0 = nouveau format
    if(count($last) > 0){
        $dir.=$last[1].'/';
    }else{
        preg_match('/0\.(.*)/', $res, $last);
        $dir.=$last[0].'/';
    }*/
    
    return $login . "/" . $code . "/";
}

function isAdmin($link)
{
    if($_SESSION['id'] == -1) return 0;
    return (mysqli_query($link, 'SELECT use_level FROM t_users_use WHERE use_id ='.$_SESSION['id'])->fetch_object()->use_level == -1 ? true : false);
}

function getInfoOfRequest($id,$link){
    return mysqli_query($link, 'SELECT * FROM t_request_req  inner join tr_typemol_tmo on tmo_id=req_tmo_id inner join tr_analyse_ana on ana_id=req_ana_id WHERE req_id ="'.$id.'"')->fetch_object();
}



function isCodeExist($code,$link)
{
    if(mysqli_query($link, 'SELECT req_code FROM t_request_req WHERE req_code = "'.$code.'"') == false) return false; //Seulement si il n'y a aucune analyse
    return (mysqli_query($link, 'SELECT req_code FROM t_request_req WHERE req_code = "'.$code.'"')->fetch_row() == false ? false : true);
}

function isHidden($link,$id)
{
    $result = false;
    $req = mysqli_query($link, 'SELECT del_id FROM tr_delete_del WHERE del_id = ' .$id);
    $nb=mysqli_num_rows($req);
    if ( $nb != 0 ){
        $result = true;
    }
    return $result;
}

function cleanString($string) {
    $nb = 60;
    $string = str_replace(' ', '-', $string);
    $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.

    if(strlen($string) > $nb)
        $string = substr($string, 0, $nb - strlen($string) );

    return $string;

 }

?>
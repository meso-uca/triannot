<?php
  //Initialisation d'une session
  ini_set('session.gc_maxlifetime', 10800);
  session_start();
  //Paramètres de connexion à la base de données
  include ("da_ba_co.php");
  include 'vars.php';
  //Connexion à la base de données
  $link=mysqli_connect(HOST,USER,MDP,DBNAME) or die("Could not connect to the database");
?>
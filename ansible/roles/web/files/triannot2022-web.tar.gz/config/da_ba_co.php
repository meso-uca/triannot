<?php
// Valeurs pour se connecter à la base de données
  define("HOST","localhost");
  define("USER","triannot2022");
  define("MDP","Tr14nn0t2022!");
  define("DBNAME","triannot2022");
?>

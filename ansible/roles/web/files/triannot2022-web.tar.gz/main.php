
<?php
    $file = null;
    $shareLink = false;
    if($page_validation){
        switch ($page){
            case 'help':
            case 'softwares':
            case 'databanks':
            case 'aknowledgments':
                $file = 'pages/'.$page.'.php';
                break;
            case 'form':
                $file = 'pages/form.php';
                break;
            case 'analysis':
                //Chercher les fichier en fonctions de la requete :
                
                if(isset($SQLGP_nospeci['req']))
                {
                    switch($SQLGP_nospeci['req']){
                        //La liste des analyses en fonction de l'utilisateur qui est connecté :
                        case 'own':
                            if($_SESSION['id'] != -1)
                            {
                                //Get des analyses en fonction de l'utilisateur
                                $sql = 'SELECT * FROM t_request_req WHERE req_login = "'. $_SESSION["loginUser"] . '"';
                                $req=mysqli_query($link,$sql);
                                $nb=mysqli_num_rows($req);
                                //Si il y a au moins un résultat
                                if ( $nb != 0 ){
                                    //$arr = tableau de résultat
                                    $arr=mysqli_fetch_all($req);
                                    $file = 'pages/analysis.php';
                                }else{
                                    $warning = $messages['no_analysis_found'];
                                }
                            }else $error = $messages['404'];
                            
                            break;

                        //L'analyse qui est renseigné grace au code
                        case 'one':
                            $sql = 'SELECT * FROM t_request_req WHERE req_code = "'. $SQLGP_nospeci['id'].'"';
                            $req=mysqli_query($link,$sql);
                            
                            $nb=mysqli_num_rows($req);
                            //Si il y a au moins un résultat
                            if ( $nb != 0 ){
                                //$arr = tableau de résultat
                                $arr=mysqli_fetch_all($req);
                                if(!isHidden($link,$arr[0][0])){
                                    $file = 'pages/analysis.php';
                                    $shareLink = $_SERVER['REQUEST_SCHEME'] .'://'. $_SERVER['HTTP_HOST'] 
                                    . explode('?', $_SERVER['REQUEST_URI'], 2)[0] . '?page=analysis&req=one&id='.$SQLGP_nospeci['id'];
                                }else  $warning = $messages['no_analysis_found'];
                               
                            }else{
                                $warning = $messages['no_analysis_found'];
                            }
                            break;
                        default:
                            $error = $messages['404'];
                            break;
                    }
                    if($warning != false && $error != false)
                    {
                        $file = 'pages/analysis.php';
                    }

                } else $error = $messages['unknown_error'];
                break;
            //Login && Register
            case 'connection':
                if(isset($SQLGP_nospeci['req']))
                {
                    switch($SQLGP_nospeci['req']){
                        case 'login':
                            $title = $texts['login_title'];
                            $mode = 1; // 1 = login
                            break;
                        case 'register':
                            $title = $texts['register_title'];
                            $mode = 2; //2 = register
                            break;
                        case 'forget':
                            $title = $texts['forget_password_title'];
                            $mode = 1;
                            if(isset($SQLGP_nospeci['login']) && !empty($SQLGP_nospeci['login']))
                            {
                                    $sql = 'SELECT * FROM t_users_use WHERE use_login = "'. $SQLGP_nospeci['login'].'"';
                                    $req=mysqli_query($link,$sql);
                                    $nb=mysqli_num_rows($req);
                                    //Si il y a au moins un résultat
                                    if ( $nb != 0 ){
                                        if(isset($SQLGP_nospeci['token']) && !empty($SQLGP_nospeci['token']) && $SQLGP_nospeci['token'] != "0")
                                        {
                                            $mode = 3; //mode 3 = changer password page
                                            $req = mysqli_fetch_all($req);
                                            //Check token
                                            if($req[0][5] == $SQLGP_nospeci['token'] && $req[0][5] != ""){
                                                if(date("Y-m-d H:i:s", strtotime("-1 hours") > $req[0][6])){

                                                    if(isset($SQLGP_nospeci['changePasswordSubmit']))
                                                    {
                                                        if(isset($SQLGP_nospeci['password']) && !empty($SQLGP_nospeci['password'])
                                                        && isset($SQLGP_nospeci['password2']) && !empty($SQLGP_nospeci['password2'])){
                                                            //les mots de passes sont les mêmes ?
                                                            if(hashPassword($SQLGP_nospeci['password']) == hashPassword($SQLGP_nospeci['password2'])){
                                                                //on peut changer le mot de passe
                                                                $sql = 'UPDATE t_users_use SET use_token = "",use_mdp = "'.hashPassword($SQLGP_nospeci['password']).'" WHERE use_login = "'. $SQLGP_nospeci['login'].'"';
                                                                $req=mysqli_query($link,$sql);
                                                                $success = $messages['success_password_change'];
                                                            } else $error = $messages['passwords_not_same'];
                                                        }else $error = $messages['form_empty'];

                                                    }

                                                }else $error = $messages['link_expired'];

                                            }else $error = $messages['wrong_token'];
                                        }else{
                                            $req = mysqli_fetch_all($req);
                                            if($req[0][4] != ""){
                                                $newToken = RandomString(25);
                                                $sql ='UPDATE t_users_use SET use_token = "'. $newToken .'", use_date_change = now() WHERE use_login = "'.$SQLGP_nospeci['login'].'"'; 
                                                mysqli_query($link,$sql);
                                                //Envois du mail
                                                $email = $req[0][4];
                                                $url = $_SERVER['REQUEST_SCHEME'] .'://'. $_SERVER['HTTP_HOST'] 
                                                . explode('?', $_SERVER['REQUEST_URI'], 2)[0] . '?page=connection&req=forget&login='.$SQLGP_nospeci['login'].'&token='.$newToken;

                                                mail($email, $messages['title_mail'], $messages['message_mail'] . $url);

                                                $success = $texts['request_password_changer'] . $SQLGP_nospeci['login'] . ' )';
                                            }
                                            else $error = $texts['request_password_changer_no_email']. $SQLGP_nospeci['login'] . ' )'; 
                                        }
                                    }else{
                                        $error = $texts['request_password_changer_user_not_in_database']. $SQLGP_nospeci['login'] . ' )';
                                    }                             
                            } else $error = $texts['login_missing'];
                            
                            break;
                        default:
                            $title = "";
                            $mode = -1;
                            $error = $messages['404'];
                            break;
                    }
                    $file = 'pages/connections.php';
                }else $error = $messages['404'];
                break;
        }
    }else $error = $messages['404'];
    ?>

    <?php
        if($error != false)
        {
        ?>
             <div class="container" style="margin-top:5%">
                <div class="alert alert-danger"><?php echo $error ?></div>
            </div>
        <?php
        }
        if($warning != false)
        {
        ?>
             <div class="container" style="margin-top:5%">
                <div class="alert alert-warning"><?php echo $warning ?></div>
            </div>
        <?php
        }
        if(isset($SQLGP_nospeci['success'])) $success = $messages['success_file_upload'];
        if($success != false){
            ?>
            <div class="container" style="margin-top:5%">
                <div class="alert alert-success"><?php echo $success ?></div>
            </div>
            <?php
        }
        if($file != null)include $file;
        ?>
        
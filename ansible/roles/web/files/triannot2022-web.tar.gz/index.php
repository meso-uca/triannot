<?php include 'config/sess.php'; ?>
<?php include('config/secur.php') ?>
<!DOCTYPE html>
<html lang="fr" class="fixed">

<head>
    <meta charset="UTF-8">
    <title><?php echo $texts['title']; ?></title>
    <link rel="icon" href="images/bandeau_microannot.ico" />
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css">
    <link rel="stylesheet" href="assets/plugins/datetimepicker-master/jquery.datetimepicker.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css">
    <link rel="stylesheet" href="assets/vendor/morris/morris.css">
    <link rel="stylesheet" href="assets/vendor/select2/select2.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="assets/vendor/summernote/summernote.css">
    <link rel="stylesheet" href="assets/vendor/summernote/summernote-bs3.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css">

    <link href="main.css" rel="stylesheet">
</head>
<!-- Theme CSS -->
<link rel="stylesheet" href="assets/stylesheets/theme.css">

<!-- Skin CSS -->
<link rel="stylesheet" href="assets/stylesheets/skins/default.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="assets/stylesheets/theme-custom.css">
<link rel="stylesheet" href="assets/stylesheets/perso.css">

<!-- Head Libs -->
<script src="assets/vendor/modernizr/modernizr.js"></script>
<script src="assets/vendor/jquery/jquery.js"></script>

<!-- <link rel="stylesheet" href="bundles/bootstrap/css/bootstrap.min.css"> -->

</head>

<body>
    <section class="body">
    
        
        <?php include('vues/header.php') ?>
        <div class="inner-wrapper">
            <?php include('vues/sidebar.php') ?>
            <!-- MAIN CONTENT-->
            <section role="main" class="content-body">
                <header class="page-header">
                <h2><?php 
                switch($page){
                    case 'form':
                        echo $texts['form_title'];
                        break;
                    case 'connection':
                        echo $texts['connection_title'];
                        break;
                    case 'logout':
                        echo $texts['form_title'];
                        break;
                    case 'help':
                        echo $texts['help_title']; 
                        break;
                    case 'analysis':
                        echo $texts['my_analysis_title'];
                        break;
                    default:
                        echo 'MicroAnnot';
                        break;
                }
                
                
                ?></h2>
                    <!-- <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="./">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                        </ol>
                        <a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
                    </div> -->
                </header>    
                <?php include('main.php') ?>              
            </section>
        </div>
    </section>
          
    <body>
            
                
            <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
            <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
            <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
            <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
            <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
            <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
            
            <!-- Specific Page Vendor -->
            <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
            <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
            <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
            <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
            <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
            <script src="assets/vendor/flot/jquery.flot.js"></script>
            <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
            <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
            <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
            <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
            <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
            <script src="assets/vendor/raphael/raphael.js"></script>
            <script src="assets/vendor/morris/morris.js"></script>
            <script src="assets/vendor/gauge/gauge.js"></script>
            <script src="assets/vendor/snap-svg/snap.svg.js"></script>
            <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
            <script src="assets/vendor/jquery-maskedinput/jquery.maskedinput.js"></script>
            <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
            <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
            <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
            <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
            <script src ="assets/plugins/datetimepicker-master/jquery.datetimepicker.js"></script>
            <script src="assets/vendor/select2/select2.js"></script>
            <script src="assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
            <script src="assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
            <script src="assets/vendor/jquery-datatables-bs3/../assets/js/datatables.js"></script>
            <script src="assets/vendor/summernote/summernote.js"></script>
            <script src="assets/jquery/pagination.js"></script>
            <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
            <script src="assets/vendor/ios7-switch/ios7-switch.js"></script>
            
            <!-- Theme Base, Components and Settings -->
            <script src="assets/javascripts/theme.js"></script>
            
            <!-- Theme Custom -->
            <script src="assets/javascripts/theme.custom.js"></script>
            
            <!-- Theme Initialization Files -->
            <script src="assets/javascripts/theme.init.js"></script>

            <script>  
        <?php
        if(isset($redirect)){
            ?>
            window.location.href = '<?php echo $redirect; ?>';
        <?php
        }
        ?>
    </script>     
    </body>
</html>

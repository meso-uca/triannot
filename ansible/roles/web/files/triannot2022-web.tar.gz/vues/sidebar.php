<aside id="sidebar-left" class="sidebar-left">
    <div class="sidebar-header">
        <div class="sidebar-title">
            Menu
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>
    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <ul class="nav nav-main">
                        <li>
                            <a href="./?page=form">
                                <i class="fa fa-file-alt" aria-hidden="true"></i>
                                <span><?php echo $texts['new_analysis']; ?></span>
                            </a>
                        </li>
                        
                        <?php if ($_SESSION['id'] != -1) { ?>
                            <li>
                                <a href="./?page=analysis&req=own">
                                    <p>
                                        <i class="fa fa-flask" aria-hidden="true"></i>
                                        <span><?php echo $texts['my_analysis']; ?></span>
                                    </p>
                                </a>
                            </li>
                        <?php } ?>
                        <li>
                            <a href="./?page=help">
                                <i class="far fa-question-circle"></i>
                                <span><?php echo $texts['help']; ?></span>
                            </a>
                        </li>
                    </ul>
                </ul>
            </nav>
        </div>
    </div>
</aside>
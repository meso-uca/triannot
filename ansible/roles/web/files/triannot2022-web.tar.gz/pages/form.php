<h1 align=center><?php echo $texts['new_analysis']; ?></h1>
<hr>

<br>

<form action="./?page=form" method="post" enctype="multipart/form-data" class="pure-form pure-form-aligned ">
    <input type=hidden name=infos value="on">
    <input type=hidden name=validmodif value="ajouter">
    <input type=hidden name=cle value="ID">
    <input type=hidden name=conditions value="" where 1"">
    <input type=hidden name=nomtable value="microannot">
    <div class="grid" >
        <div class="form-group"  style='display: flex;align-items:baseline'>
            <label class="col-md-3 control-label"><?php echo $texts['file_span']; ?></label>
            <div class="col-md-6" >
                <div class="fileupload fileupload-new" data-provides="fileupload">
                    <div class="input-append">
                        <div class="uneditable-input">
                            <i class="fa fa-file fileupload-exists"></i>
                            <span class="fileupload-preview"></span>
                        </div>
                        <span class="btn btn-default btn-file">
                            <span class="fileupload-exists"><?php echo $texts['file_change']; ?></span>
                            <span class="fileupload-new"><?php echo $texts['file_select']; ?></span>
                            <input type="file" id="sequences" name="sequences" />
                        </span>
                        <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload"><?php echo $texts['file_delete']; ?></a>
                    </div>
                </div>
            </div>
        </div>
        <!--  -->

        <!-- </div><br /> -->
        <h4><?php echo $texts['min_length']; ?></h4>
        <div class="form-group" style='display: flex;align-items:center'>
            <label for="min_size" class="col-md-3 control-label"><?php echo $texts['min_size']; ?></label>
            <div class="col-sm-6">
                <input type="number" class="form-control" id="inputDefault" name="min_size">
            </div>
        </div>
        <div class="form-group" style='display: flex;align-items:center'>
            <label for="max_size" class="col-md-3 control-label"><?php echo $texts['max_size']; ?></label>
            <div class="col-sm-6">
                <input type="number" class="form-control" id="inputDefault" name="max_size">
            </div>
        </div>
        <h4><?php echo $texts['parameters']; ?></h4>
        <div class="form-group" >
            <label class="col-md-3 control-label"><?php echo $texts['sequence_type']; ?></label>
            <div class="col-md-6">
                <select class="form-control" name="type_sequence">
                <?php
                        $sql = 'SELECT * FROM tr_typemol_tmo';
                        $req=mysqli_query($link,$sql);
                        $nb=mysqli_num_rows($req);
                        foreach (mysqli_fetch_all($req) as $key => $value) {
                            echo "<option value='". $value[0] . "'>".$value[1]."</option>";
                        }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group" >
            <label class="col-md-3 control-label"><?php echo $texts['splitseq']; ?></label>
            <div class="col-md-6">
                <div class="switch switch-sm switch-primary">
                    <input type="checkbox" name="splitseq"  data-plugin-ios-switch>
                </div>
            </div>
        </div>
        <div class="form-group" style='display: flex;align-items:center'>
            <label for="max_size" class="col-md-3 control-label"><?php echo $texts['overlap']; ?></label>
            <div class="col-sm-6">
                <input type="number" class="form-control" id="inputDefault" name="overlap" value="50000">
            </div>
        </div>
        <div class="form-group" >
            <label class="col-md-3 control-label"><?php echo $texts['xml_steps']; ?></label>
            <div class="col-md-6">
                <select class="form-control" name="xml_step">
                <?php
                        $sql = 'SELECT * FROM tr_analyse_ana';
                        $req=mysqli_query($link,$sql);
                        $nb=mysqli_num_rows($req);
                        foreach (mysqli_fetch_all($req) as $key => $value) {
                            echo "<option value='". $value[0] . "'>".$value[1]."</option>";
                        }
                    ?>
                </select>
            </div>
        </div>
        
        </br>
        <button class="btn btn-primary col-md-5" name="submitForm" onclick="submit(this)" type="submit"><?php echo $texts['button_form_default']; ?></button>
        <button type="reset" class="btn btn-default col-md-5 col-md-offset-2" value="reset" name="reset"><?php echo $texts['button_reset_default']; ?></button>
    </div>
    </div>
</form>
<script>
    function submit(el)
    {
        $(el).val("Sending ...");
    }
</script>

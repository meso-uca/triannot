<h1 align=center><?php echo $texts['help_top_page']; ?></h1>
<hr><br>
<a href="images/220621_TriAnnotArchitecture.png" target="_blank">
<img width="100%" src="images/220621_TriAnnotArchitecture.png" />
<i class="fas fa-file-download"></i> pdf</a>
<br><br>
<p>

    Philippe Leroy <a href="mailto:philippe.leroy@inrae.fr">philippe.leroy@inrae.fr</a> <br>
    David Grimbichler <a href="mailto:david.grimbichler@uca.fr">david.grimbichler@uca.fr</a> <br> 
    Matthieu Reichstadt <a href="mailto:matthieu.reichstadt@inrae.fr">matthieu.reichstadt@inrae.fr</a><br>

</p>
<br><br>
<img src="images/Logo_INRAE.png" />
